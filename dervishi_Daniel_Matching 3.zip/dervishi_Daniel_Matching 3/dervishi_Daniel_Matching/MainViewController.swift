import UIKit
//Variable to check if the view controller was opened before
var openedBefore = false
class MainViewController: UIViewController {

    @IBOutlet weak var player1NameTxt: UITextField!
    @IBOutlet weak var player2NameTxt: UITextField!
//Creating a constant for easy access of user defaults
    let defaults = UserDefaults.standard
//Function for sorting the leaderboard scores that takes in an int array and a string array
        func sort(array1: [Int], array2: [String]){
         var array1a = array1
         var array2a = array2
//Sort the int array and assign it to isSorted
                let isSorted = array1a.sorted()
//keep the loop going until the array is sorted
                 while isSorted != array1a{
//Loop for the int array
                     for index in 0...array2a.count - 1{
//if the index is 0 continue
                         if index == 0{
                             continue
// if the value at the current index is smaller than the value at the last index do the following
                         }else if array1a[index] < array1a[index - 1]{
//Swap the two numbers and the names at the same index in the names array
                                 array1a.swapAt(index, index - 1)
                                 array2a.swapAt(index, index - 1)
                             }
                     }



                 }
//If they wanted a leaderboard and the gamemode was practice do the following
                 if wantsLeaderBoard == 0{
//Reverse the two arrays
                     array1a = array1a.reversed()
                     array2a = array2a.reversed()
//set the two global variables to the placeholder varaibles
                     namesArrayPractice = array2a
                     numbersArrayPractice = array1a
//If they wanted a leaderboard and the gamemode was timed do the following
                 }else if wantsLeaderBoard == 1{
//Reverse the two arrays
                     array1a = array1a.reversed()
                     array2a = array2a.reversed()
//set the two global variables to the placeholder varaibles
                     namesArrayTimed = array2a
                     numbersArrayTimed = array1a
                 }
             }
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewDidAppear(_ animated: Bool) {
//If it is the first time opening the app do the following
        if openedBefore == false{
//set opened before to true
            openedBefore = true
//set the array variables to what they were saved to using user defaults
        if let numsPrac = defaults.object(forKey: "numPrac") as? [Int]{
        numbersArrayPractice = numsPrac
        }
        
        if let namesPrac = defaults.object(forKey: "namePrac") as? [String]{
        namesArrayPractice = namesPrac
        }
        if let numsTime = defaults.object(forKey: "numTime") as? [Int]{
        numbersArrayTimed = numsTime
        }
        if let namesTime = defaults.object(forKey: "nameTime") as? [String]{
        namesArrayTimed = namesTime
        }
            }
//If the user wanted a leaderboard and the gamemode was practice do the following
            if wantsLeaderBoard == 0{
//Add the name to the practice name array and the value to the practice value array
                                                       namesArrayPractice.append(Array(LbDict.keys)[0])
                                                       numbersArrayPractice.append(Array(LbDict.values)[0])
//If the user wanted a leaderboard and the gamemode was timed do the following
                                       }else if wantsLeaderBoard == 1{
//Add the name to the timed name array and the value to the timed value array
                                                       namesArrayTimed.append(Array(LbDict.keys)[0])
                                                       numbersArrayTimed.append(Array(LbDict.values)[0])

                                       }
//If the user wanted a leaderboard and the gamemode was practice do the following
        if wantsLeaderBoard == 0{
//Sort the practice leaderboard arrays and set wants leaderboard to - 1
            sort(array1: numbersArrayPractice, array2: namesArrayPractice)
            wantsLeaderBoard = -1

        }
//If the user wanted a leaderboard and the gamemode was timed do the following
        if wantsLeaderBoard == 1{
//Sort the timed leaderboard arrays and set wants leaderboard to - 1
            sort(array1: numbersArrayTimed, array2: namesArrayTimed)
            wantsLeaderBoard = -1

        }

//Save the four leaderboard related arrays using user defaults
        defaults.set(numbersArrayTimed, forKey: "numTime")
        defaults.set(namesArrayTimed, forKey: "nameTime")
        defaults.set(numbersArrayPractice, forKey: "numPrac")
        defaults.set(namesArrayPractice, forKey: "namePrac")
    }
    @IBAction func unwindToVC1(unwindSegue:UIStoryboardSegue) {
//Unwind segue
    }
//Variables for the player names
    var player1Name = "Player 1"
    var player2Name = "Player 2"

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//If the title of sender is Help, do nothing
        if (sender! as AnyObject).currentTitle == "Help" {
//If the title of sender is leaderboard, do nothing
        } else if (sender! as AnyObject).currentTitle == "LeaderBoard"{
//Otherwinse do the following
        }else{
//Create a vairable for the main game vc
                   let myVC = segue.destination as! ViewController
//set these variables in the other vc to the values in the current vc
                   myVC.gameMode = gamemode
                   myVC.player1Name = player1Name
                   myVC.player2Name = player2Name
               }


    }
//Creating a variable gamemode
    var gamemode = 0
    @IBAction func singlePlayer(_ sender: UIButton) {
//if the text field for player 1 name is not empty, set it to player1name otherwise use the defualt name
        if player1NameTxt.text != ""{
        player1Name = player1NameTxt.text!
        }else{
        player1Name = "Player1"
        }
//If character count of player1 name exceeds 10 present the follwing alert
        if player1Name.count > 10{
            Alerts.showActionAlertWithOkay(on: self, with: "Caution!", message: "Player 1's Name is too long. Make sure it is less than 10 characters!") { _ in}
        }else{
//set gamemode to 0 and perform mainSegue
gamemode = 0
performSegue(withIdentifier: "mainSegue", sender: self)
        }
        
    }
    @IBAction func Player(_ sender: UIButton) {

//if the text field for player 2 name is not empty, set it to player2name otherwise use the defualt name
        if player2NameTxt.text != "" {
        player2Name = player2NameTxt.text!
        }else{
         player2Name = "Player2"
        }
//if the text field for player 1 name is not empty, set it to player1name otherwise use the defualt name
        if player1NameTxt.text != ""{
        player1Name = player1NameTxt.text!
        }else{
        player1Name = "Player1"
        }
//If both character counts exceed ten present the follwoing alert box
        if player1Name.count > 10 && player2Name.count > 10{
            Alerts.showActionAlertWithOkay(on: self, with: "Caution!", message: "Both Players names are too long. Make sure they are less than 10 characters!") { _ in}
//If player1 character count exceeds 10 present the follwing alert box
    }else if player1Name.count > 10{
            Alerts.showActionAlertWithOkay(on: self, with: "Caution!", message: "Player 1's Name is too long. Make sure it less than 10 characters!") { _ in}
//If player2 character count exceeds 10 present the following alert box
        }else if player2Name.count > 10{
            Alerts.showActionAlertWithOkay(on: self, with: "Caution!", message: "Player 2's Name is too long. Make sure it is less than 10 characters!") { _ in}
        }else{
//set gamemode 2 and perform main segue
            gamemode = 2
        performSegue(withIdentifier: "mainSegue", sender: self)
        }
    }
    @IBAction func timeMode(_ sender: UIButton) {
//if the text field for player 1 name is not empty, set it to player1name otherwise use the defualt name
        if player1NameTxt.text != ""{
        player1Name = player1NameTxt.text!
        }else{
        player1Name = "Player1"
        player2Name = "Player2"
        }
        
//If the character count for player1Name exceeds 10 present the following alert box
        if player1Name.count > 10{
            Alerts.showActionAlertWithOkay(on: self, with: "Caution!", message: "Player 1's Name is too long. Make sure it is less than 10 characters!") { _ in}
        }else{
//Set gamemode to timed and perform main segue
gamemode = 1
performSegue(withIdentifier: "mainSegue", sender: self)
        }
    }
    @IBAction func helpScreen(_ sender: UIButton) {
    }
}
