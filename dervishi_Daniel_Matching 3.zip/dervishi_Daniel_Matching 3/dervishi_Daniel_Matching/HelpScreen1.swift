//
//  HelpScreen1.swift
//  dervishi_Daniel_Matching
//
//  Created by Daniel Dervishi on 2019-12-14.
//  Copyright © 2019 Period Three. All rights reserved.
//

import UIKit

class HelpScreen1: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
//Set the help label to the rules
        lblHelp.text = """
Normal Mode
Goal: Match all the sports
Scoring: The more consecutive guesses you make the more points you will earn
        
Time Mode
Goal: Match all the characters in a minute or less
Scoring: Same as normal mode
        
Two Player Mode
Goal: Match more than the other player
If one player gets a correct match they get to continue their turn. If they guess wrong it switches to the other player's turn
Scoring: Same as normal mode
"""
    }
    
    @IBOutlet weak var lblHelp: UILabel!
    
    


}
