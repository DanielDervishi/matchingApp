import UIKit
//Global variables for to keep track of names and scores for leaderboard
public var namesArrayPractice:[String] = []
public var numbersArrayPractice: [Int] = []
public var namesArrayTimed:[String] = []
public var numbersArrayTimed: [Int] = []
//Used to determine whether user wants leaderboard and the gamemode they came from
public var wantsLeaderBoard = -1
//Dictionary used to keep track of the player name and score once the user chooses to add to the leaderboard
public  var LbDict: [String:Int] = [:]
class ViewController: UIViewController {
    @IBOutlet weak var lblCountDown: UILabel!
    @IBOutlet weak var LblScorePlayer1: UILabel!
    @IBOutlet var btnCollection: [UIButton]!
    @IBOutlet weak var startGameButton: UIButton!
    @IBOutlet weak var LblScorePlayer2: UILabel!
    @IBOutlet weak var giveUpButton: UIButton!
    @IBOutlet weak var newGameButton: UIButton!
    @IBOutlet weak var back: UIButton!
//Variables used to flip the cards
    var myIndex = 0
    var myIndex2 = 15
//Creating the alert box where the user adds themselves to the leaderboard
    var alert = UIAlertController(title: "Leaderboard", message: "Insert your name and press ok to be part of the leaderboards", preferredStyle: .alert)

//Function to do a cool flip sequence at the start of the game
     func startGameFlip () {
         DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
            self.btnCollection[self.myIndex].setImage(#imageLiteral(resourceName: "sports"), for: .normal)
            Animations.individual(vc: self, speed: 0.9, button: self.btnCollection[self.myIndex])
             self.myIndex += 1
             if self.myIndex == 16 {
                 return
             }
             self.startGameFlip()
         }
     }
    //Function to do a cool flip sequence at the end of the game
    func endGameFlip () {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
            self.btnCollection[self.myIndex2].setImage(self.theThing[self.myIndex2], for: .normal)
           Animations.individualLast(vc: self, speed: 0.9, button: self.btnCollection[self.myIndex2])
            self.myIndex2 -= 1
            if self.myIndex2 == -1 {
                return
            }
            self.endGameFlip()
        }
    }
//Array of images for the matching game
var theThing: [UIImage] = [#imageLiteral(resourceName: "cycling"),#imageLiteral(resourceName: "cycling"),#imageLiteral(resourceName: "abseiling"),#imageLiteral(resourceName: "abseiling"), #imageLiteral(resourceName: "volleyball-player-motion") , #imageLiteral(resourceName: "volleyball-player-motion") ,#imageLiteral(resourceName: "river-rafting"),#imageLiteral(resourceName: "river-rafting"),#imageLiteral(resourceName: "throwing-javelin"),#imageLiteral(resourceName: "throwing-javelin"),#imageLiteral(resourceName: "tennis-player-with-racket (1)"),#imageLiteral(resourceName: "tennis-player-with-racket (1)"),#imageLiteral(resourceName: "weight-lifting"),#imageLiteral(resourceName: "weight-lifting"),#imageLiteral(resourceName: "skateboarder"),#imageLiteral(resourceName: "skateboarder")]
//Array of numbers that are used later to decide which buttons need to be dissabled and when
var intArray: [Int] = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
//Creation of the timer
var myTimer = Timer()
// Initial value of the timer
var myTime:Int = 60
//Function to reduce the timer
        func thetimer(){
            myTime -= 1
            lblCountDown.text = "Time Left: \(myTime)"
        }

    override func viewDidLoad() {
        super.viewDidLoad()
//Adding a text field for the leaderboard alert box
        alert.addTextField(configurationHandler: { (textField) -> Void in
//Adding a placeholder to the alert box
            textField.placeholder = "Enter Name"
        })
//Adding the ok action for when the user decides to add an input to the leaderboard
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (action) -> Void in
//setting player1Name to the input from the user
            self.player1Name = (alert?.textFields![0].text)!
//When the input is less than 10 characters do the following
            if self.player1Name.count <= 10{
// If the gamemode is practice, set wantsLeaderBoard to 0
                if self.gameMode == 0{
                    wantsLeaderBoard = 0
// If the gamemode is timed, set wantsLeaderBoard to 1
                }else if self.gameMode == 1{
                    wantsLeaderBoard = 1
                }
// if they want to add to the practice leaderboard, set LbDict to the name and score of player1
            if wantsLeaderBoard == 0{
                LbDict = [self.player1Name:self.scorePlayer1]
// if they want to add to the timed leaderboard, set LbDict to the name of player 1 and the time left
            }else if wantsLeaderBoard == 1{
                LbDict = [self.player1Name:self.myTime]
            }
//Press the back button
            self.back.sendActions(for: .touchUpInside)


//If the input is longer than 10 characters, present a new alert box telling the user to make their input less than 10 characters
            }else{
            self.present(self.alert, animated: true, completion: nil)
                alert?.message = "Name to long. Reduce to 10 characters or less"
        }
            
        }))
        //Add a cancel action that does nothing
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { _ in
            
            
        }))
//Shuffle the picture array
        theThing.shuffle()
//Hide the countDown label and player1Score label
        lblCountDown.isHidden = true
        LblScorePlayer1.isHidden = true
//Set the text of player2Scores label to an empty string
        LblScorePlayer2.text = ""
//Hide all of the buttons in the button collection
        for index in btnCollection{
            index.isHidden = true
        }
//Hide the give up and new game buttons
        giveUpButton.isHidden = true
        newGameButton.isHidden = true

    }

//Reset Function
    func reset(){
//Set all the following variables back to their defaults
        intArray = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
        turn = 0
        bothFlipped = 0
        btnThingy = 0
        exponential = 0
        scorePlayer1 = 0
        scorePlayer2 = 0
        matches = 0
//Un-Hide the start game button
        startGameButton.isHidden = false
        myIndex2 = 15
        myIndex = 0
        myTime = 60
//Stop the timer
        myTimer.invalidate()
//Hide everThing in the butotn collection and set their images to nil
        for index in btnCollection{
            index.isHidden = true
            index.setImage(nil, for: .normal)
        }
//hide the score labels
        LblScorePlayer1.isHidden = true
        LblScorePlayer2.isHidden = true
//Hide the countDown label
        lblCountDown.isHidden = true
//Hide the newGameButton
        newGameButton.isHidden = true
//Hide the Give up Button
        giveUpButton.isHidden = true
//Re shuffle the image array
                theThing.shuffle()
    }
//Create a turn variable that constantly updates depending on whos turn it is
var turn = 0
//player 1 and 2 names variable
var player1Name = "Player 1"
var player2Name = "Player 2"
//Variable for the gamemode
var gameMode = 1
//Variable to check whether or not both cards are flipped
var bothFlipped = 0
//Varaible to hold on to the first picture clicked before the images flip back
var btnThingy = 0
//Used to calculate the score
var exponential = 0
//Scores of both players
var scorePlayer1 = 0
var scorePlayer2 = 0
//Used to count how many matches habe been made
var matches = 0
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    @IBAction func btnCollectionPressed(_ sender: UIButton) {
//Add one to bothFlipped
bothFlipped += 1
//If both flipped is 1 do the following
if bothFlipped == 1{
//Set the image to the corresponding element in the images array with an animation
    sender.setImage(theThing[sender.tag - 1], for: .normal)
    Animations.simple(vc: self, speed: 0.5, button: sender)
//btnThing keeps track of the tag of the first button that is clicked
    btnThingy = sender.tag - 1
//Disable the sender
    sender.isEnabled = false
//If both images are flipped do the following
}else if bothFlipped == 2{
//disable the current button
    sender.isEnabled = false
//Dissable every button
        for index in intArray{
            btnCollection[index].isEnabled = false
        }
//Set the image to the corresponding element in the images array with an animation
    sender.setImage(theThing[sender.tag - 1], for: .normal)
    Animations.simple(vc: self, speed: 0.5, button: sender)
//set bothFlipped to 0
    bothFlipped = 0
//Disable all the buttons in the buttons collection
        for index in intArray{
            btnCollection[index].isEnabled = false
        }
// if both flipped images are the same do the following
if sender.image(for: .normal) == btnCollection[btnThingy].image(for: .normal){
//add 1 to matches
    matches += 1
//disable sender
    sender.isEnabled = false
//disable the first button that was clicked before they switch
    btnCollection[btnThingy].isEnabled = false
//disable the current button
    btnCollection[sender.tag - 1].isEnabled = false
//after 0.6 seconds enable everything in btn collecion that has not been matched
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            for index in self.intArray{
                    self.btnCollection[index].isEnabled = true
            }
//Once you reach 8 matches do the following
if self.matches == 8{
//disable the give up button
    self.giveUpButton.isEnabled = false
//stop the timer
        self.myTimer.invalidate()
//disable each button
            for index in self.btnCollection{
                index.isEnabled = false
            }
// if you are in practice mode the following alert show up by calling baraams alert struct
    if self.gameMode == 0{
   Alerts.showActionAlertWithOkayAndCancelAndOther(on: self, with: "Game Over", message: "Your score was \(self.scorePlayer1)", resetGame: { _ in
//It resets the game
    self.reset()
    }) { _ in
//Presents the leaderboard alert box
        self.present(self.alert, animated: true, completion: nil)
        }
//If the gamemode is timed present the follwoing alert box
        }else if self.gameMode == 1{

            Alerts.showActionAlertWithOkayAndCancelAndOther(on: self, with: "Game Over", message: "You had \(self.scorePlayer1) seconds to spare!", resetGame: { _ in
//Reset the game
             self.reset()
             }) { _ in
//Present the leader board alert box
                 self.present(self.alert, animated: true, completion: nil)

             }
//If its two player mode do the following
    }else{
        //If player 1 wins present the following
        if self.scorePlayer1 > self.scorePlayer2{
            Alerts.showActionAlertWithOkayAndCancel2(on: self, with: "game Over", message: "The winner was \(self.player1Name) with a score of \(self.scorePlayer1) points") { _ in
//reset game
                self.reset()
            }
//If player2 wins present the following
        }else if self.scorePlayer1 < self.scorePlayer2{
            Alerts.showActionAlertWithOkayAndCancel2(on: self, with: "game Over", message: "The winner was \(self.player2Name) with a score of \(self.scorePlayer2) points", cancelAction: { _ in
//Restart the game
                self.reset()
            })
//If its a tie do the following
        }else{
            Alerts.showActionAlertWithOkayAndCancel2(on: self, with: "Game Over", message: "The Game resulted in a tie. Each player had a score of  \(self.scorePlayer1)", cancelAction: { _ in
//Restart the game
                self.reset()
            })
        }
    
    }
    }
    }
//Remove the tag of the first button pressed before the cards flip back from intArray
    intArray =  intArray.filter {$0 != btnThingy}
//Remove the tag of the second button pressed before the cards flip back from intArray
    intArray = intArray.filter {$0 != sender.tag - 1}
//If its player 2's turn do the follwing
    if turn == 1{
//Add to the score exponentially
    scorePlayer2 += Int(pow(2, Double(exponential)))
//If its player 1's turn do the follwing
    }else if turn == 0{
//Add to the score exponentially
    scorePlayer1 += Int(pow(2, Double(exponential)))
    }
//Add 1 to the exponential variable
    exponential += 1
//If you dont get a match
}else{
//Switch turns
    if turn == 1 && gameMode == 2{
        turn = 0
    }else if turn == 0 && gameMode == 2{
        turn = 1
    }
//Reset exponential
    exponential = 0
//Set the images back to what they origanally were after 0,6 seconds and do a cool aniation aswell with the awesome struct i built
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            sender.setImage(#imageLiteral(resourceName: "sports"), for: .normal)
            Animations.simple(vc: self, speed: 0.5, button: sender)
            self.btnCollection[self.btnThingy].setImage(#imageLiteral(resourceName: "sports"), for: .normal)
            Animations.simple(vc: self, speed: 0.5, button: self.btnCollection[self.btnThingy])
                for index in self.intArray{
                    self.btnCollection[index].isEnabled = true
                }
        }
        }
    }
//Update the scores labels
    LblScorePlayer1.text = "\(player1Name)'s Score: \(scorePlayer1)"
    if gameMode == 2{
    LblScorePlayer2.text = "\(player2Name)'s Score: \(scorePlayer2)"
        }
//Update the turn labels depending on whos turn it is
       if turn == 0 && gameMode == 2{
    lblCountDown.text = "\(player1Name)'s turn"
        }else if turn == 1  && gameMode == 2{
    lblCountDown.text = "\(player2Name)'s turn"
        }

        }
    @IBAction func startGameButtonPressed(_ sender: UIButton) {
//Show player1Label and set the text to the following
LblScorePlayer1.isHidden = false
LblScorePlayer1.text = "\(player1Name)'s Score: \(scorePlayer1)"
//Show the countdown Label
lblCountDown.isHidden = false
//If the gamemode is two player show the second players score label
        if gameMode == 2{
            LblScorePlayer2.isHidden = false
        }
//disable every button
for index2 in btnCollection{
index2.isEnabled = false
}
//Do that cool flip thingy at the beginning of the game
startGameFlip()
//After 3 seconds re enable all the buttons
    DispatchQueue.main.asyncAfter(deadline: .now() + 3){
        for index2 in self.btnCollection{
    index2.isEnabled = true
        }
//Show the give up button and enable it
    self.giveUpButton.isHidden = false
    self.giveUpButton.isEnabled = true
//Show the new game button
    self.newGameButton.isHidden = false
    }
        
//Hide the start game button
startGameButton.isHidden = true
//Show all the buttons in the button Collection
    for index in btnCollection{
        index.isHidden = false
    }
//If the gamemode is practice set lblCountdown to an empty string
if gameMode == 0{
lblCountDown.text = ""
//If the gamemode is timed set the count down label to the following
}else if gameMode == 1{
lblCountDown.text = "Time Left: 60"
//After 2.6 seconds do the following
    DispatchQueue.main.asyncAfter(deadline: .now() + 2.6) {
//Start the timer
self.myTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true, block: {_ in self.thetimer()
//If the timer reaches 0 stop it and disable all the buttons
if self.myTime == 0{
    self.myTimer.invalidate()
        for index in self.btnCollection{
            index.isEnabled = false
        }
//Use the alerts struct to present the following alert box
    Alerts.showActionAlertWithOkayOnly(on: self, with: "Game Over", message: "You failed to match all of the pictures. You are a dissapointment because a minute is more than enough time.") { _ in
//Press the give up button
    self.giveUpButton.sendActions(for: .touchUpInside)
    }

}
})
}
//If it is two player mode set label count down to an empty string
}else if gameMode == 2{
    lblCountDown.text = ""

        }
//If the gamemode is two player set lblScorePlayer1 and lblScorePlayer2 to the following
               if gameMode == 2{
                    LblScorePlayer1.text = "\(player1Name)'s Score: \(scorePlayer1)"


                    LblScorePlayer2.text = "\(player2Name)'s Score: \(scorePlayer2)"
//update turns depending on who's turn it is
                       if turn == 0 && gameMode == 2 {
                    lblCountDown.text = "\(player1Name)'s turn"
                        }else if turn == 1  && gameMode == 2{
                    lblCountDown.text = "\(player2Name)'s turn"
                        }
                }
//If the gamemode is timed, hide player 1's score
        if gameMode == 1{
            LblScorePlayer1.isHidden = true
        }
}

    @IBAction func giveUpButtonPressed(_ sender: UIButton) {
//Disable the new game and give up button
        giveUpButton.isEnabled = false
        newGameButton.isEnabled = false
//Do the cool flip animation for the end of a game
endGameFlip()
//Stop the timer
        myTimer.invalidate()
//After 2.6 seconds re enable the new game button
         DispatchQueue.main.asyncAfter(deadline: .now() + 2.6) {
            self.newGameButton.isEnabled = true
        }
    }
    
    @IBAction func newGameButtonPressed(_ sender: UIButton) {
//Reset the game
        reset()
    }
}

