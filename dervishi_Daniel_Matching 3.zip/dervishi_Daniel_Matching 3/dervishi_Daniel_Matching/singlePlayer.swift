//
//  singlePlayer.swift
//  dervishi_Daniel_Matching
//
//  Created by Period Three on 2019-12-03.
//  Copyright © 2019 Period Three. All rights reserved.
//

import Foundation

class singlePlayer: <#super class#> {
    <#code#>
}
