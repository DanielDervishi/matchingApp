
import UIKit

class tableViewViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var mainTable: UITableView!
    @IBOutlet weak var coolSwitch: UISegmentedControl!
//Create a variable for table score
    var tableScore: [Any] = []
    var tableName: [Any] = []
    var units = "points"
    
    override func viewDidAppear(_ animated: Bool) {
//Set tableName and tableScore to the following off startup and reload the table data
                tableName = namesArrayPractice
                tableScore = numbersArrayPractice
        mainTable.reloadData()
    
    }
            override func viewDidLoad() {

                super.viewDidLoad()

    }

        @available(iOS 2.0, *)
//Counting the number of rows needed in the table
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return (tableName.count)
    }
//creating the cells for each row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "cell")
        cell.textLabel?.text =  "\(tableName[indexPath.row]) : \(tableScore[indexPath.row]) \(units) "
        return cell
   
    }

    @IBAction func coolSwitchPressed(_ sender: UISegmentedControl) {

        switch coolSwitch.selectedSegmentIndex {
//Whenever the segmented switch is changed from timed to practice the following happens
        case 0:
//set table name and score to practice and set units to points
            tableName = namesArrayPractice
            tableScore = numbersArrayPractice
             units = "points"
//reload the table
            mainTable.reloadData()
//Whenever the segmented switch is changed from practice to timed the following happens
        case 1:
//set table name and score to timed and set units to seconds left
            tableName = namesArrayTimed
            tableScore = numbersArrayTimed
                       units = "seconds left"
//reload table data
mainTable.reloadData()
        default:
//Otherwise do nothing
            break
        }
    }
}
